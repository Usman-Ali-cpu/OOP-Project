#include <iostream>
#include <vector>
#include <fstream>
#include "file.h"
#include "medicine.h"
#include "medicine_data.h"
using namespace std;

class Order : public MedicineData
{
private:
	int orderID;
	int itemCount;
	Medicine medicine;
	double TotalBill;
public:
	Order()
	{
	}
	Order(int ID, int items)
	{
		orderID = ID;
		itemCount = items;
		TotalBill = 0;
	}
	void setOrderID(int ID)
	{
		orderID = ID;
	}
	void setitemCount(int count)
	{
		itemCount = count;
	}
	int getOrderID()
	{
		return orderID;
	}
	double getTotalBill()
	{
		return TotalBill;
	}
	void addBill(string name)
	{
		double p = getpassingMedicinePrice(name);
		TotalBill += p;
	}
	double getpassingMedicinePrice(string name)
	{
		Medicine med = medicine.getByMedicineName(name);
		return med.getMedicinePrice();
	}
	bool isInStoke(string name)
	{
		Medicine med = medicine.getByMedicineName(name);
		if (med.getMedicineStockCount() > 0)
		{
			return true;
		}
		return false;
	}
	bool checkMedicine(string name)
	{
		int id;
		if (!medicine.findByMedicineName(name))
		{
			return false;
		}
		if (isInStoke(name))
		{
			return true;
		}
		else if (!isInStoke(name))
		{
			Medicine med = medicine.getByMedicineName(name);
			cout << "Medicine ID : " << med.getMedicineID() << endl;
			int id = med.getMedicineID();
			MedicineDataHolder hold = getMedicineByID(id);

			string f = hold.formula;
			if (findMedicineByFormula(f))
			{
				hold = getMedicineByFormula(f);
				return true;
			}
		}
		return false;
	}
	void setCart(string name)
	{
		TotalBill += getpassingMedicinePrice(name);
		cout << "Your medicine has been add to cart" << endl;
	}
	void takeOrder()
	{
		cout << "Your total bill is : " << TotalBill << endl;
	}
	~Order()
	{
	}
};