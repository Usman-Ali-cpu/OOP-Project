#pragma once

#ifndef FILE_H
#define FILE_H
#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

class File
{
protected:
	vector<string> reader(const string &fileName)
	{
		ifstream file;
		file.open(fileName);
		string data;
		vector<string> result;
		while (file.is_open() && !file.eof())
		{
			getline(file, data);
			if (!data.empty())
			{
				result.push_back(data);
			}
		}
		if (file.is_open())
			file.close();
		return result;
	}
	void writer(const string &fileName, const vector<string> &data)
	{
		ofstream file;
		file.open(fileName, ios::app);
		if (file.is_open())
		{
			for (string s : data)
			{
				file << s + "\n";
			}
			file.close();
		}
	}
	void clearwriter(const string &fileName, const vector<string> &data)
	{
		ofstream file;
		file.open(fileName);
		if (file.is_open())
		{
			for (string s : data)
			{
				file << s + "\n";
			}
			file.close();
		}
	}
};

#endif