#include <iostream>
#include <vector>
#include <fstream>
#include "file.h"
using namespace std;

class Employee : public File
{
private:
    string empName;
    int empID;
    double empSal;
    string emphiredate;
public:
    Employee()
    {
    }
    Employee(string name, int ID, double salary, string hiredate)
    {
        empName = name;
        empID = ID;
        empSal = salary;
        emphiredate = hiredate;
    }
    void setEmpName(string name)
    {
        empName = name;
    }
    void setEmpHiredate(string date)
    {
        emphiredate = date;
    }
    void setEmpID(int ID)
    {
        empID = ID;
    }
    void setEmpSalary(int salary)
    {
        empSal = salary;
    }
    string getEmpName()
    {
        return empName;
    }
    string getEmpHiredate()
    {
        return emphiredate;
    }
    int getEmpID()
    {
        return empID;
    }
    double getEmpSalary()
    {
        return empSal;
    }
    void addEmployee(const vector<string> &employeeData)
    {
        writer("Employee.txt", employeeData);
    }
    vector<string> readEployee()
    {
        return reader("Employee.txt");
    }
    void showEmpDetail()
    {
        cout << "\t\t\t       Ogglugugllu Medicines \n";
        cout << "\t\t\t Medical Store Management System \n";
        cout << "\t ==================================================================\n\n";
        cout << "\t ------------------------------------------------------------------\n";
        cout << "\t ||\t\t1.  All Medicines And Price \t\t\t ||\n\n";
        cout << "\t EmployeeName   \tEmployeeId  \t EmpSalary  \t Emphiredate \t \n";

        vector<string> employeeData = readEployee();
        for (string subData : employeeData)
        {
            for (int i = 0; i < 4; i++)
            {
                int index = subData.find_first_of(',');
                switch (i)
                {
                case 0:
                    empName = subData.substr(0, index);
                    break;
                case 1:
                    empID = stoi(subData.substr(0, index));
                    break;
                case 2:
                    empSal = stod(subData.substr(0, index));
                    break;
                case 3:
                    emphiredate = subData.substr(0, index);
                    break;
                }
                subData.erase(0, index + 1);
            }
            for (int i = 0; i < 4; i++)
            {
                switch (i)
                {
                case 0:
                    cout << "\t " << empName << "  \t    ";
                    break;
                case 1:
                    cout << "\t " << empID << "  \t   ";
                    break;
                case 2:
                    cout << "\t " << empSal << "  \t    ";
                    break;
                case 3:
                    cout << "\t " << emphiredate << "  \t    " << endl;
                    break;
                }
            }
        }
    }
};