#include <iostream>
#include <vector>
#include <fstream>
#include "file.h"
using namespace std;

class AdminData : public File
{
private:
    int loginID;
    string loginPassword;
public:
    AdminData()
    {
        loginID = 0;
        loginPassword = " ";
    }
    void addAdminData(const vector<string> &data)
    {
        writer("Admin.txt", data);
    }
    bool addAdmin(int id, string pass)
    {
        string logindata;
        logindata = to_string(id) + "," + pass + "\n";
        vector<string> s;
        s.push_back(logindata);
        addAdminData(s);
        cout << "Admin has been added " << endl;
    }
    vector<string> readAdmin()
    {
        return reader("Admin.txt");
    }
    bool checkLogin(int id, string checkpassword)
    {
        vector<string> loginData = readAdmin();
        for (string subData : loginData)
        {
            for (int i = 0; i < 2; i++)
            {
                int index = subData.find_first_of(',');
                switch (i)
                {
                case 0:
                    loginID = stoi(subData.substr(0, index));
                    break;
                case 1:
                    loginPassword = subData.substr(0, index);
                    break;
                }
                subData.erase(0, index + 1);
            }
            if (loginID == id && loginPassword == checkpassword)
            {
                cout << "You have successfully login " << endl;
                return true;
            }
        }
        return false;
    }
    ~AdminData()
    {
    }
};