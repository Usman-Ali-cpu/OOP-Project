#pragma once

#ifndef MEDICINE_H
#define MEDICINE_H

#include <iostream>
#include <vector>
#include <iomanip>
#include <fstream>
#include "file.h"
using namespace std;

class Medicine : public File
{
private:
    string medicineName;
    int medicineID;
    double medicinePrice;
    int medicineStockCount;

public:
    Medicine()
    {
        medicineName = " ";
        medicineID = 0;
        medicinePrice = 0;
        medicineStockCount = 0;
    }
    ~Medicine()
    {
    }
    void setMedicineName(string name)
    {
        medicineName = name;
    }
    void setMedicineID(int ID)
    {
        medicineID = ID;
    }
    void setMedicinePrice(double price)
    {
        medicinePrice = price;
    }
    void setMedicineStock(int count)
    {
        medicineStockCount = count;
    }
    string getMedicineName()
    {
        return medicineName;
    }
    int getMedicineID()
    {
        return medicineID;
    }
    double getMedicinePrice()
    {
        return medicinePrice;
    }
    int getMedicineStockCount()
    {
        return medicineStockCount;
    }
    void addMedicine(const vector<string> &data)
    {
        writer("Medicine.txt", data);
    }
    vector<string> readMedicine()
    {
        return reader("Medicine.txt");
    }
    string toUPPER(string s)
    {
        for (int i = 0; i < s.length(); i++)
        {
            s[i] = toupper(s[i]);
        }
        return s;
    }
    void printMedicines()
    {
        cout << "\t\t\t       Ogglugugllu Medicines \n";
        cout << "\t\t\t Medical Store Management System \n";
        cout << "\t ==================================================================\n\n";
        cout << "\t ------------------------------------------------------------------\n";
        cout << "\t ||\t\t1.  All Medicines And Price \t\t\t ||\n\n";
        cout << "\t MedicineID   \tMedicineName  \t\tPrice  \t    CountStoke \t \n";

        vector<string> medicinedetail = readMedicine();
        for (string s : medicinedetail)
        {
            for (int i = 0; i < 4; i++)
            {
                int index = s.find_first_of(',');
                switch (i)
                {
                case 0:
                    medicineID = stoi(s.substr(0, index));
                    break;
                case 1:
                    medicineName = s.substr(0, index);
                    break;
                case 2:
                    medicinePrice = stod(s.substr(0, index));
                    break;
                case 3:
                    medicineStockCount = stoi(s.substr(0, index));
                    break;
                }
                s.erase(0, index + 1);
            }
            for (int i = 0; i < 4; i++)
            {
                switch (i)
                {
                case 0:
                    cout << "\t " << medicineID << "  \t    ";
                    break;
                case 1:
                    cout << "\t " << toUPPER(medicineName) << "  \t   ";
                    break;
                case 2:
                    cout << "\t " << setprecision(3)<<medicinePrice << "  \t    ";
                    break;
                case 3:
                    cout << "\t " << medicineStockCount << "  \t    " << endl;
                    break;
                }
            }
        }
    }

    void updateStockMedicines(string name)
    {
        vector<string> medicinedetail = readMedicine();
        for (string s : medicinedetail)
        {
            for (int i = 0; i < 4; i++)
            {
                int index = s.find_first_of(',');
                switch (i)
                {
                case 0:
                    medicineID = stoi(s.substr(0, index));
                    break;
                case 1:
                    medicineName = s.substr(0, index);
                    break;
                case 2:
                    medicinePrice = stod(s.substr(0, index));
                    break;
                case 3:
                    medicineStockCount = stoi(s.substr(0, index));
                    if (medicineName == name)
                    {
                        medicineStockCount--;
                        string tem = to_string(medicineStockCount);
                        s.replace(0, 2, tem);
                    }
                    break;
                }
                s.erase(0, index + 1);
            }
            clearwriter("Medicine.txt", medicinedetail);
        }
    }
    Medicine &getByMedicineID(int id)
    {
        vector<string> medicinedetail = readMedicine();
        for (string s : medicinedetail)
        {
            for (int i = 0; i < 4; i++)
            {
                int index = s.find_first_of(',');
                switch (i)
                {
                case 0:
                    medicineID = stoi(s.substr(0, index));
                    break;
                case 1:
                    medicineName = s.substr(0, index);
                    break;
                case 2:
                    medicinePrice = stod(s.substr(0, index));
                    break;
                case 3:
                    medicineStockCount = stoi(s.substr(0, index));
                    break;
                }
                s.erase(0, index + 1);
            }
            if (medicineID == id)
            {
                return *this;
            }
        }
    }
    bool findByMedicineID(int id)
    {
        vector<string> medicinedetail = readMedicine();
        for (string s : medicinedetail)
        {
            for (int i = 0; i < 4; i++)
            {
                int index = s.find_first_of(',');
                switch (i)
                {
                case 0:
                    medicineID = stoi(s.substr(0, index));
                    break;
                case 1:
                    medicineName = s.substr(0, index);
                    break;
                case 2:
                    medicinePrice = stod(s.substr(0, index));
                    break;
                case 3:
                    medicineStockCount = stoi(s.substr(0, index));
                    break;
                }
                s.erase(0, index + 1);
            }
            if (medicineID == id)
            {
                return true;
            }
        }
        return false;
    }
    Medicine &getByMedicineName(string nm)
    {
        vector<string> medicinedetail = readMedicine();
        for (string s : medicinedetail)
        {
            for (int i = 0; i < 4; i++)
            {
                int index = s.find_first_of(',');
                switch (i)
                {
                case 0:
                    medicineID = stoi(s.substr(0, index));
                    break;
                case 1:
                    medicineName = s.substr(0, index);
                    break;
                case 2:
                    medicinePrice = stod(s.substr(0, index));
                    break;
                case 3:
                    medicineStockCount = stoi(s.substr(0, index));
                    break;
                }
                s.erase(0, index + 1);
            }
            if (medicineName == nm)
            {
                return *this;
            }
        }
    }
    bool findByMedicineName(string nm)
    {
        vector<string> medicinedetail = readMedicine();
        for (string s : medicinedetail)
        {
            for (int i = 0; i < 4; i++)
            {
                int index = s.find_first_of(',');
                switch (i)
                {
                case 0:
                    medicineID = stoi(s.substr(0, index));
                    break;
                case 1:
                    medicineName = s.substr(0, index);
                    break;
                case 2:
                    medicinePrice = stod(s.substr(0, index));
                    break;
                case 3:
                    medicineStockCount = stoi(s.substr(0, index));
                    break;
                }
                s.erase(0, index + 1);
            }
            if (medicineName == nm)
            {
                return true;
            }
        }
        return false;
    }
};
#endif