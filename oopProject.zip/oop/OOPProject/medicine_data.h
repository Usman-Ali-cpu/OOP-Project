#pragma once

#ifndef MEDICINEDATA_H
#define MEDICINEDATA_H

#include <iostream>
#include <vector>
#include <fstream>
#include "file.h"
using namespace std;

struct MedicineDataHolder
{
    int medicineID;
    string company;
    string formula;
};
class MedicineData : public File
{
private:
    MedicineDataHolder *holder;
    int size;
    int medicineID;
    string company;
    string formula;
public:
    MedicineData()
    {
        size = 1;
        holder = new MedicineDataHolder[size];
        medicineID = 0;
        company = "none";
        formula = "none";
    }
    ~MedicineData()
    {
    }
    void addMedicineData(const vector<string> &data)
    {
        writer("MedicineData.txt", data);
    }
    vector<string> readMedicineData()
    {
        return reader("MedicineData.txt");
    }
    string toUPPER(string s)
    {
        for (int i = 0; i < s.length(); i++)
        {
            s[i] = toupper(s[i]);
        }
        return s;
    }
    void printMedicinesData()
    {
        cout << "\t MedicineID   \t Manufacturer  \t\tMedicine Formula   \t \n";
        vector<string> get = readMedicineData();
        for (string s : get)
        {
            for (int i = 0; i < 3; i++)
            {
                int index = s.find_first_of(',');
                switch (i)
                {
                case 0:
                    medicineID = stoi(s.substr(0, index));
                    break;
                case 1:
                    company = s.substr(0, index);
                    break;
                case 2:
                    formula = s.substr(0, index);
                    break;
                }
                s.erase(0, index + 1);
            }
            for (int i = 0; i < 3; i++)
            {
                switch (i)
                {
                case 0:
                    cout << "\t " << medicineID << "  \t    ";
                    break;
                case 1:
                    cout << "\t " << toUPPER(company)  << "  \t    ";
                    break;
                case 2:
                    cout << "\t " << formula << "  \t    " << endl;
                    break;
                }
            }
        }
    }
    void printMedicineByCompany(string com)
    {
        cout << "---------------------------------------" << endl;
        vector<string> medicinedata = readMedicineData();
        for (string s : medicinedata)
        {
            for (int i = 0; i < 3; i++)
            {
                int index = s.find_first_of(',');
                switch (i)
                {
                case 0:
                    medicineID = stoi(s.substr(0, index));
                    break;
                case 1:
                    company = s.substr(0, index);
                    break;
                case 2:
                    formula = s.substr(0, index);
                    break;
                }
                s.erase(0, index + 1);
            }
            if (company == com)
            {
                for (int i = 0; i < 3; i++)
                {
                    switch (i)
                    {
                    case 0:
                        cout << "Medicine ID:  " << medicineID << endl;
                        break;
                    case 1:
                        cout << "Medicine company:  " << toUPPER(company) << endl;
                        break;
                    case 2:
                        cout << "Medicine Formula :  " << toUPPER(formula) << endl;
                        break;
                    }
                }
                MedicineData data;
                MedicineDataHolder hold;
                hold = data.getMedicineByCompany(company);
                Medicine med;
                Medicine m;
                m = med.getByMedicineID(medicineID);
                cout << "Medicine Name :  " << toUPPER(m.getMedicineName()) << endl;
                cout << "Medicine Price :  " << m.getMedicinePrice() << endl;
                cout << "---------------------------------------" << endl;
            }
        }
    }
    bool findMedicineByFormula(string fm)
    {
        medicineDataGetter();
        bool flag = false;
        for (int i = 0; i < size; i++)
        {
            if (holder[i].formula == fm)
            {
                flag = true;
            }
        }
        return flag;
    }
    MedicineDataHolder getMedicineByFormula(string fm)
    {
        medicineDataGetter();
        MedicineDataHolder temp;
        bool flag = false;
        for (int i = 0; i < size; i++)
        {
            if (holder[i].formula == fm)
            {
                temp.medicineID = holder[i].medicineID;
                temp.formula = holder[i].formula;
                temp.company = holder[i].company;
            }
        }
        return temp;
    }
    bool findMedicineByCompany(string com)
    {
        medicineDataGetter();
        bool flag = false;
        cout << "Results for this company are-> " << endl;
        for (int i = 0; i < size; i++)
        {
            if (holder[i].company == com)
            {
                flag = true;
            }
        }
        return flag;
    }
    MedicineDataHolder getMedicineByCompany(string com)
    {
        medicineDataGetter();
        MedicineDataHolder temp;
        bool flag = false;
        for (int i = 0; i < size; i++)
        {
            if (holder[i].company == com)
            {
                temp.medicineID = holder[i].medicineID;
                temp.formula = holder[i].formula;
                temp.company = holder[i].company;
            }
        }
        return temp;
    }
    bool findMedicineByID(int id)
    {
        medicineDataGetter();
        bool flag = false;
        for (int i = 0; i < size; i++)
        {
            if (holder[i].medicineID == id)
            {
                flag = true;
            }
        }
        return flag;
    }
    MedicineDataHolder getMedicineByID(int nm)
    {
        medicineDataGetter();
        MedicineDataHolder temp;
        bool flag = false;
        for (int i = 0; i < size; i++)
        {
            if (holder[i].medicineID == nm)
            {
                temp.medicineID = holder[i].medicineID;
                temp.formula = holder[i].formula;
                temp.company = holder[i].company;
                return temp;
            }
        }
    }
    void incSize()
    {
        MedicineDataHolder *temp;
        temp = new MedicineDataHolder[size];
        for (int i = 0; i < size; i++)
        {
            temp[i].company = holder[i].company;
            temp[i].formula = holder[i].formula;
            temp[i].medicineID = holder[i].medicineID;
        }
        delete[] holder;
        holder = NULL;
        size++;
        holder = new MedicineDataHolder[size];
        for (int i = 0; i < size - 1; i++)
        {
            holder[i].company = temp[i].company;
            holder[i].formula = temp[i].formula;
            holder[i].medicineID = temp[i].medicineID;
        }
    }
    void medicineDataGetter()
    {
        size = 1;
        holder = new MedicineDataHolder[size];
        vector<string> medicinedata = readMedicineData();
        for (string s : medicinedata)
        {
            for (int i = 0; i < 3; i++)
            {
                int index = s.find_first_of(',');
                switch (i)
                {
                case 0:
                    medicineID = stoi(s.substr(0, index));
                    break;
                case 1:
                    company = s.substr(0, index);
                    break;
                case 2:
                    formula = s.substr(0, index);
                    break;
                }
                s.erase(0, index + 1);
            }
            holder[size - 1].company = company;
            holder[size - 1].formula = formula;
            holder[size - 1].medicineID = medicineID;
            incSize();
        }
    }
};

#endif