#include <iostream>
#include <iomanip>
#include <vector>
#include <fstream>
#include "file.h"
#include "medicine.h"
#include "medicine_data.h"
#include "order.h"
#include "admin_data.h"
#include "employee.h"
using namespace std;

static int BILL = 0;
string tolower(string s)
{
    for (int i = 0; i < s.length(); i++)
    {
        s[i] = tolower(s[i]);
    }
    return s;
}
string toUPPER(string s)
{
    for (int i = 0; i < s.length(); i++)
    {
        s[i] = toupper(s[i]);
    }
    return s;
}
void printHeader()
{
    system("cls");
    cout << "\t\t\t       Ogglugugllu Medicines \n";
    cout << "\t\t\t Medical Store Management System \n";
    cout << "\t\t==================================================\n\n";
    cout << "\t\t--------------------------------------------------\n";
    cout << "\t\t||\t1.  Show All Medicines And Price \t ||\n";
    cout << "\t\t||\t2.  Buy Medicines \t\t\t ||\n";
    cout << "\t\t||\t3.  Search for Medicine\t\t\t ||\n";
    cout << "\t\t||\t4.  Add a Medicine To Store\t\t ||\n";
    cout << "\t\t||\t5.  Add New Employee To Store \t\t ||\n";
    cout << "\t\t||\t6.  Show Employee Details  \t\t ||\n";
    cout << "\t\t||\t7.  Show medicine by company  \t\t ||\n";
    cout << "\t\t||\t8. Exit\t\t\t\t\t ||\n";
    cout << "\t\t--------------------------------------------------\n";
}

void orderNewMedicine()
{
    Order ord;
    system("cls");
    cout << "\t\t\t       Ogglugugllu Medicines \n";
    cout << "\t\t\t Medical Store Management System \n";
    cout << "\t\t==================================================\n\n";
    cout << "\t\t--------------------------------------------------\n";
    vector<string> appender;

    string mediName;
    int numberOfTab;
    double bill = 0;
    int end = 0;
    do
    {
        cout << "Enter name of medicine: ";
        cin >> mediName;
        Medicine med;
        med.updateStockMedicines(mediName);
        mediName = tolower(mediName);
        if (!ord.checkMedicine(mediName))
        {
            cout << "Sorry, we dont have this medicine ! " << endl;
        }
        else if (ord.checkMedicine(mediName))
        {
            cout << "Enter number of tablets: ";
            cin >> numberOfTab;
            BILL += ord.getpassingMedicinePrice(mediName) * numberOfTab;
            string pass = mediName + "  \t||\t" + to_string(ord.getpassingMedicinePrice(mediName)) + "\n";
            appender.push_back(pass);
        }

        cout << "Enter 1 to get total bill : " << endl;
        cout << "Enter 0 to continue buying: " << endl;
        cin >> end;

    } while (end == 0);
    cout<<"\t\t--------------------------------------------------\n";
    cout << "\t\tYour Order detail is -> " << endl << endl;
    cout << "\t\tMedi Name\t" << "|| \t" << "Price" << endl;

    for (string str : appender)
    {
        cout << "\t\t"<<str;
    }
    cout << "\n\t\t   ___________________________________________";
    cout << "\n\t\t   || \t   Your total bill is : Rs." << BILL<< "        ||";
    cout << "\n\t\t   -------------------------------------------" << endl;
    cout << "\n\t\tThanks for choosing Oggluggugloo  " << endl;
    cout << "\t\t \"AND WHEN I FALL ILL, ALLAH IS THE ONE WHO CURES ME\" " << endl;
    cout<<"\t\t----------------------------------------------------\n";
}
void showAllMedicine()
{
    Medicine medprice;
    medprice.printMedicines();
    cout << endl << endl;
    MedicineData data;
    data.printMedicinesData();
    cout << "\t-------------------------------------------------------------------" << endl;
}

void takeNewOrder()
{
    orderNewMedicine();
}

bool searchMedicine()
{
    Medicine medi;
    Medicine medprice3;
    MedicineData fmcom;
    string mediName;
    cout << "Enter name of Medicine : ";
    cin >> mediName;
    mediName = tolower(mediName);
    MedicineDataHolder hold;
    if (!medprice3.findByMedicineName(mediName))
    {
        cout << "We could not find this medicine! " << endl;
        cout << "Enter medicine formula if you want to have other named medicine with same formula : ";
        string formula;
        cin >> formula;
        formula = tolower(formula);
        MedicineData d;
        if (!d.findMedicineByFormula(formula))
        {
            cout << "We dont have any Medicine with this Formula " << endl;
            return false;
        }
        hold = fmcom.getMedicineByFormula(formula);
        int id = hold.medicineID;
        if (medprice3.findByMedicineID(id))
        {
            Medicine temp = medprice3.getByMedicineID(id);
            cout << "------------------------------------------------ " << endl;
            cout << "Medicine ID is : " <<setw(10)<< temp.getMedicineID() << endl;
            cout << "Medicine name is : "<<setw(14) << toUPPER(temp.getMedicineName()) << endl;
            cout << "Medicine Price : " <<setw(10)<< temp.getMedicinePrice() << endl;
            MedicineData data;
            MedicineDataHolder hold;
            hold = data.getMedicineByID(temp.getMedicineID());
            cout << "Medicine Company : " <<setw(14)<< toUPPER(hold.company) << endl;
            cout << "Medicine Formula : " <<setw(14)<< toUPPER(hold.formula) << endl;
            cout << "------------------------------------------------ " << endl;
        }
        else if (!medprice3.findByMedicineID(id))
        {
            cout << "You dont Have any medicine with this name and formula " << endl;
        }
    }
    else
    {
        medi = medprice3.getByMedicineName(mediName);
        int id = medi.getMedicineID();
        MedicineDataHolder holder = fmcom.getMedicineByID(id);
        Medicine m;
        Medicine p;
        p = m.getByMedicineID(holder.medicineID);

        cout << "------------------------------------------------ " << endl;
        cout << "Medicine Id is : "<<setw(10) << holder.medicineID << endl;
        cout << "Medicine Name : " <<setw(14)<< toUPPER(mediName) << endl;
        cout << "Medicine Price : "<<setw(10) << p.getMedicinePrice() << endl;
        cout << "Medicine Formula is : " << toUPPER(holder.formula) << endl;
        cout << "Medicine Company is : " << toUPPER(holder.company) << endl;
        cout << "------------------------------------------------ " << endl;
    }
    return true;
}

void addMedicineToStore()
{
    Medicine medicine;
    MedicineData mediData;
    int id, count;
    string mediName;
    double price;
    cout << "Enter Medicine ID : ";
    cin >> id;
    cout << "Enter medicine name : ";
    cin >> mediName;
    mediName = tolower(mediName);
    cout << "Enter Medicine Price : ";
    cin >> price;
    cout << "Enter Medicine count: ";
    cin >> count;
    string append1 = to_string(id) + "," + tolower(mediName) + "," + to_string(price) + "," + to_string(count);
    vector<string> med1;
    med1.push_back(append1);
    medicine.addMedicine(med1);

    string company, formula;
    cout << "Enter medicine Company : ";
    cin >> company;
    company = tolower(company);
    cout << "Enter medicine Formula : ";
    cin >> formula;
    formula = tolower(formula);
    string append = to_string(id) + "," + tolower(company) + "," + tolower(formula);
    vector<string> med;
    med.push_back(append);
    mediData.addMedicineData(med);
}

void addEmployee()
{
    Employee emp;
    int id;
    double sal;
    string name;
    string date;
    cout << "Enter Employee ID : ";
    cin >> id;
    cout << "Enter Emmployee name : ";
    cin >> name;
    name = tolower(name);
    cout << "Enter Employee salary : ";
    cin >> sal;
    cout << "Enter Employee Hiredate: ";
    cin >> date;
    string append1 = tolower(name) + "," + to_string(id) + "," + to_string(sal) + "," + tolower(date);
    vector<string> med1;
    med1.push_back(append1);
    emp.addEmployee(med1);
}

void showEmployees()
{
    Employee emp;
    emp.showEmpDetail();
}

bool searchMedicineByCompany()
{
    MedicineData data;
    string company;
    cout << "Enter name of company : ";
    cin >> company;
    company = tolower(company);
    if (!data.findMedicineByCompany(company))
    {
        cout << "We have no poduct of this company: " << endl;
        return false;
    }
    data.printMedicineByCompany(tolower(company));
    return true;
}

int main()
{
    cout << "\t\t\t       Ogglugugllu Medicines \n";
    cout << "\t\t\t Medical Store Management System \n";
    cout << "\t ==================================================================\n\n";
    cout << "\t ----------You are Required to login as Admin-------------------------\n";

    int id;
    string pass;

    cout << "Enter your loginId: ";
    cin >> id;
    cout << "Enter your login password: ";
    cin >> pass;
    pass = tolower(pass);
    AdminData add;
    while (!add.checkLogin(id, pass))
    {
        cout << "Wrong ID or password :( " << endl;
        cout << "Enter your loginId: ";
        cin >> id;
        cout << "Enter your login password: ";
        cin >> pass;
        pass = tolower(pass);
    }
    while (true)
    {
        printHeader();
        int check;
        cout << "Enter your choice : ";
        cin >> check;

        switch (check)
        {
        case 1:
        {
            showAllMedicine();
            system("pause");
        }
        break;
        case 2:
        {
            takeNewOrder();
            system("pause");
        }
        break;
        case 3:
        {
            searchMedicine();
            system("pause");
        }
        break;
        case 4:
        {
            addMedicineToStore();
            system("pause");
        }
        break;
        case 5:
        {
            addEmployee();
            system("pause");
        }
        break;
        case 6:
        {
            showEmployees();
            system("pause");
        }
        break;
        case 7:
        {
            searchMedicineByCompany();
            system("pause");
        }
        break;
        case 8:
        {
            exit(0);
        }

        break;
        default:
            cout << "You Entered wrong choice ! " << endl;
            system("pause");
        }
    }
    return 0;
}